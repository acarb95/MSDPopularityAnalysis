/*
The MIT License (MIT)
[OSI Approved License]
The MIT License (MIT)
Copyright (c) 2014 Daniel Glasson
Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
 */

package geocode;

import geocode.kdtree.KDTree;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;

import org.apache.commons.logging.Log;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.mapreduce.Mapper.Context;

import com.amazonaws.services.s3.AmazonS3;

/**
 * 
 * Created by Daniel Glasson on 18/05/2014. Uses KD-trees to quickly find the
 * nearest point
 * 
 * ReverseGeoCode reverseGeoCode = new ReverseGeoCode(new
 * FileInputStream("c:\\AU.txt"), true);
 * System.out.println("Nearest to -23.456, 123.456 is " +
 * geocode.nearestPlace(-23.456, 123.456));
 */
public class ReverseGeoCode {
	KDTree<GeoName> kdTree;
	AmazonS3 s3;

	// Get placenames from http://download.geonames.org/export/dump/
	@SuppressWarnings("rawtypes")
	public ReverseGeoCode(Context context, String key, boolean majorOnly, Log LOG) throws IOException, URISyntaxException {
		Configuration conf = context.getConfiguration();
        System.out.println("fs.defaultFS : - " + conf.get("fs.defaultFS"));
        // It prints uri  as : hdfs://10.214.15.165:9000 or something...
        String uri = conf.get("fs.defaultFS");
        FileSystem fs = FileSystem.get(new URI(uri), conf);
        Path path = new Path(key);

		ArrayList<GeoName> arPlaceNames;
		arPlaceNames = new ArrayList<GeoName>(3730373);

		// Read the geonames file in the directory
		BufferedReader in = new BufferedReader(new InputStreamReader(fs.open(path)));
		
		String str;
		//System.out.println(split.length);
		int count = 0;
		try {
			while ((str = in.readLine()) != null) {
				if (count % 10000 == 0) {
					System.out.print(count + "-");
					context.progress();
					context.setStatus(""+count);
				}
				arPlaceNames.add(new GeoName(str));
				count++;					
			}
			//}
		} catch (IOException ex) {
			System.out.println("Exception thrown!!");
			System.out.println("Message: " + ex.getMessage());
			in.close();
			throw ex;
		}
		//s.close();
		in.close();
		System.out.println("\nDONE");
		kdTree = new KDTree<GeoName>(arPlaceNames);

	}

	public GeoName nearestPlace(double latitude, double longitude) {
		return kdTree.findNearest(new GeoName(latitude, longitude));
	}
}
