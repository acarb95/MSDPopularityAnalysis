#! /bin/bash

for ip in `cat ~/cs480/HDF5Converter/ips` 
do
    echo "Uploading to ip: $ip"
    scp -r -i ~/AWS/acarbona-east-key-pair.pem $@ ec2-user@$ip:~/
done

