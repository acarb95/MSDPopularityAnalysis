#! /bin/bash

echo "Starting 26 processes..."

for letter in {A..Z}
do
    IN_DIRECTORY=/mnt/MSD-data/data
    OUT_DIRECTORY=/mnt/MSD-selected/output
    nohup gnome-terminal -x bash -c "ssh -t -i ~/AWS/acarbona-east-key-pair.pem ec2-user@$1 'cd ~; sudo nohup bash run_converter.sh $IN_DIRECTORY/$letter $OUT_DIRECTORY; bash;'" &
done
