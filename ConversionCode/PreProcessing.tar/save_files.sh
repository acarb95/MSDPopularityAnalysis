#! /bin/bash

DIRECTORY=$1

if [ ! -n "$DIRECTORY" ]; then
    DIRECTORY=/mnt/MSD-text-data/data
fi

for letter in {A..Z}
do
    for letter2 in {A..E}
    do 
        if [ ! -d "$DIRECTORY/data/" ]; then
            sudo mkdir $DIRECTORY/data/
        fi
        if [ ! -d "$DIRECTORY/data/$letter/" ]; then
            sudo mkdir $DIRECTORY/data/$letter/
        fi
        if [ ! -d "$DIRECTORY/data/$letter/$letter2/" ]; then
            sudo mkdir $DIRECTORY/data/$letter/$letter2/
        fi
        for letter3 in {A..Z}; 
        do
            echo "Copying $DIRECTORY/data/$letter/$letter2/$letter3"
            sudo cp -r /mnt/MSD-data/data/$letter/$letter2/$letter3 $DIRECTORY/data/$letter/$letter2/
        done
    done
done
