#! /bin/bash

DIRECTORY=$1
OUTPUTDIR=$2
echo "Starting 26 processes for $DIRECTORY..."

for letter in {A..Z}
do
    for letter2 in {A..Z}
    do
        DIRECTORY2=$DIRECTORY/$letter/$letter2
        echo "Running on $DIRECTORY2"; 
        for file in $DIRECTORY2
        do
            if [ -d "$file" ] && [ "$file" != "$DIRECTORY" ]; then 
                echo "     Starting process for $file"
                nohup java -classpath ./hdf-java/lib/*:. -Djava.library.path="./hdf-java/lib/linux/" HDF5GettersV3 $file $OUTPUTDIR
            fi
        done
    done
done
